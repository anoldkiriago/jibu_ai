
import React from 'react';
import { Camera, Mic, Globe, Shield, Users, Star, Brain, Zap } from 'lucide-react';

export const Features = () => {
  const features = [
    {
      icon: Camera,
      title: 'Photo Recognition',
      description: 'Simply snap a photo of any homework question and get instant AI-powered explanations.',
      color: 'from-coral to-coral-600',
    },
    {
      icon: Mic,
      title: 'Voice-to-Text & Read-Aloud',
      description: 'Speak your questions in English or Swahili, and hear explanations read back to you.',
      color: 'from-teal to-teal-600',
    },
    {
      icon: Globe,
      title: 'Multilingual Support',
      description: 'Get explanations in English or Swahili with perfect cultural context.',
      color: 'from-sunny to-sunny-600',
    },
    {
      icon: Shield,
      title: 'Anonymous Mode',
      description: 'Ask questions privately without storing any identifying information.',
      color: 'from-lavender to-purple-600',
    },
    {
      icon: Brain,
      title: 'Emotion-Aware AI',
      description: 'AI detects frustration and responds with gentler, more encouraging explanations.',
      color: 'from-success to-green-600',
    },
    {
      icon: Zap,
      title: 'Offline Mode',
      description: 'Queue questions while offline and sync automatically when internet returns.',
      color: 'from-coral to-teal',
    },
    {
      icon: Users,
      title: 'Family Profiles',
      description: 'Manage multiple children with personalized learning histories and progress tracking.',
      color: 'from-teal to-sunny',
    },
    {
      icon: Star,
      title: 'Homework Panic Button',
      description: 'One-tap connection to live tutors for urgent homework help (premium feature).',
      color: 'from-sunny to-coral',
    },
  ];

  return (
    <section id="features" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold font-poppins text-charcoal mb-6">
            Revolutionary Features for Modern Parents
          </h2>
          <p className="text-xl text-midgrey max-w-3xl mx-auto">
            Everything you need to support your child's education journey, powered by cutting-edge AI technology with local context.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group p-6 bg-white rounded-2xl border border-gray-100 hover:border-coral-200 hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 transform"
            >
              <div className={`inline-flex p-4 rounded-2xl bg-gradient-to-r ${feature.color} mb-6 group-hover:scale-110 transition-transform duration-300`}>
                <feature.icon className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold font-poppins text-charcoal mb-4 group-hover:text-coral transition-colors">
                {feature.title}
              </h3>
              <p className="text-midgrey leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Unique Features Highlight */}
        <div className="mt-20 bg-gradient-to-r from-coral/10 to-teal/10 rounded-3xl p-8 border border-coral-200">
          <div className="text-center">
            <h3 className="text-2xl font-bold font-poppins text-charcoal mb-4">
              🇰🇪 Built for Kenyan Families
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-4xl mb-2">💳</div>
                <h4 className="font-semibold text-charcoal">M-Pesa Integration</h4>
                <p className="text-midgrey text-sm">Seamless mobile payments</p>
              </div>
              <div className="text-center">
                <div className="text-4xl mb-2">🏠</div>
                <h4 className="font-semibold text-charcoal">Local Context</h4>
                <p className="text-midgrey text-sm">Kenyan curriculum focus</p>
              </div>
              <div className="text-center">
                <div className="text-4xl mb-2">🤝</div>
                <h4 className="font-semibold text-charcoal">Parent Community</h4>
                <p className="text-midgrey text-sm">Connect with other parents</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
