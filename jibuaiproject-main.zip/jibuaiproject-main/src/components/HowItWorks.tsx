
import React from 'react';
import { Camera, MessageSquare, BookOpen } from 'lucide-react';

export const HowItWorks = () => {
  const steps = [
    {
      step: 1,
      icon: Camera,
      title: 'Snap or Speak',
      description: 'Take a photo of the homework question or speak it aloud in English or Swahili.',
      color: 'from-coral to-coral-600',
    },
    {
      step: 2,
      icon: MessageSquare,
      title: 'AI Analysis',
      description: 'Jibu AI analyzes the question and prepares a clear, age-appropriate explanation with emotional awareness.',
      color: 'from-teal to-teal-600',
    },
    {
      step: 3,
      icon: BookOpen,
      title: 'Learn Together',
      description: 'Receive step-by-step explanations you can easily share with your child, with read-aloud support.',
      color: 'from-sunny to-sunny-600',
    },
  ];

  return (
    <section id="how-it-works" className="py-20 bg-gradient-to-br from-coral/5 to-teal/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold font-poppins text-charcoal mb-6">
            How Jibu AI Works
          </h2>
          <p className="text-xl text-midgrey max-w-3xl mx-auto">
            Get homework help in three simple steps. It's that easy, whether you're speaking English or Swahili!
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12">
          {steps.map((step, index) => (
            <div key={index} className="text-center group">
              {/* Step Number */}
              <div className="relative mb-8">
                <div className={`inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-r ${step.color} text-white text-3xl font-bold font-poppins mb-6 group-hover:scale-110 transition-transform duration-300 shadow-2xl`}>
                  {step.step}
                </div>
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-10 left-full w-full h-1 bg-gradient-to-r from-coral/30 to-teal/30 rounded-full"></div>
                )}
              </div>

              {/* Icon */}
              <div className={`inline-flex p-6 rounded-3xl bg-gradient-to-r ${step.color} mb-8 group-hover:scale-105 transition-transform duration-300 shadow-xl`}>
                <step.icon className="h-10 w-10 text-white" />
              </div>

              {/* Content */}
              <h3 className="text-2xl font-semibold font-poppins text-charcoal mb-4">
                {step.title}
              </h3>
              <p className="text-midgrey leading-relaxed max-w-sm mx-auto text-lg">
                {step.description}
              </p>
            </div>
          ))}
        </div>

        {/* Interactive Demo CTA */}
        <div className="text-center mt-20">
          <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-10 border border-coral-200 max-w-3xl mx-auto shadow-2xl">
            <div className="text-6xl mb-6">🎯</div>
            <h3 className="text-3xl font-semibold font-poppins text-charcoal mb-6">
              Ready to see Jibu AI in action?
            </h3>
            <p className="text-midgrey mb-8 text-lg">
              Try our interactive demo with a real homework question. Experience the magic of instant AI explanations!
            </p>
            <button className="bg-gradient-to-r from-coral to-teal hover:from-coral-600 hover:to-teal-600 text-white px-10 py-4 rounded-2xl font-semibold text-lg shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-105">
              Try Interactive Demo
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
