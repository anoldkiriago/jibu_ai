
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Menu, X, BookOpen, Globe } from 'lucide-react';

export const Navigation = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [language, setLanguage] = useState('EN');

  const navItems = [
    { name: 'Home', href: '#home' },
    { name: 'How It Works', href: '#how-it-works' },
    { name: 'Features', href: '#features' },
    { name: 'Pricing', href: '#pricing' },
    { name: 'FAQ', href: '#faq' },
    { name: 'Contact', href: '#contact' },
  ];

  const toggleLanguage = () => {
    setLanguage(language === 'EN' ? 'SW' : 'EN');
  };

  return (
    <nav className="sticky top-0 z-50 bg-cream/95 backdrop-blur-lg border-b border-coral-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <div className="bg-gradient-to-r from-coral to-teal p-2 rounded-xl">
              <BookOpen className="h-6 w-6 text-white" />
            </div>
            <span className="text-xl font-bold font-poppins bg-gradient-to-r from-coral to-teal bg-clip-text text-transparent">
              Jibu AI
            </span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className="text-charcoal hover:text-coral font-medium transition-colors duration-200"
              >
                {item.name}
              </a>
            ))}
          </div>

          {/* Language Toggle & CTA Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            <Button
              onClick={toggleLanguage}
              variant="outline"
              size="sm"
              className="text-teal border-teal-300 hover:bg-teal-50 flex items-center space-x-1"
            >
              <Globe className="h-4 w-4" />
              <span>{language}</span>
            </Button>
            <Button variant="outline" className="text-coral border-coral-300 hover:bg-coral-50">
              Sign In
            </Button>
            <Button className="bg-coral hover:bg-coral-600 text-white">
              Try Free
            </Button>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-md text-charcoal hover:text-coral hover:bg-coral-50"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-coral-200">
            <div className="flex flex-col space-y-4">
              {navItems.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="text-charcoal hover:text-coral font-medium transition-colors duration-200 px-2 py-1"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.name}
                </a>
              ))}
              <div className="flex flex-col space-y-2 pt-4 border-t border-coral-200">
                <Button
                  onClick={toggleLanguage}
                  variant="outline"
                  size="sm"
                  className="text-teal border-teal-300 hover:bg-teal-50 flex items-center justify-center space-x-1"
                >
                  <Globe className="h-4 w-4" />
                  <span>{language === 'EN' ? 'Switch to Swahili' : 'Switch to English'}</span>
                </Button>
                <Button variant="outline" className="text-coral border-coral-300 hover:bg-coral-50">
                  Sign In
                </Button>
                <Button className="bg-coral hover:bg-coral-600 text-white">
                  Try Free
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};
