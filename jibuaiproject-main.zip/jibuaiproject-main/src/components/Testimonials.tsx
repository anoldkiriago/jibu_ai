
import React, { useEffect, useState } from 'react';
import { Star, Quote } from 'lucide-react';

export const Testimonials = () => {
  const [showConfetti, setShowConfetti] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setShowConfetti(true);
            setTimeout(() => setShowConfetti(false), 3000);
          }
        });
      },
      { threshold: 0.5 }
    );

    const section = document.getElementById('testimonials');
    if (section) observer.observe(section);

    return () => observer.disconnect();
  }, []);

  const testimonials = [
    {
      name: 'Grace Wanjiku',
      role: 'Mother of 3',
      location: 'Nairobi',
      content: 'Jibu AI has transformed homework time! My children actually enjoy learning now, and the Swahili explanations help them understand concepts better.',
      rating: 5,
      subject: 'Mathematics & Science',
    },
    {
      name: 'David Ochieng',
      role: 'Father of 2',
      location: 'Mombasa',
      content: 'The voice feature is incredible! I can ask questions while cooking dinner, and the emotion-aware responses really help when my daughter gets frustrated.',
      rating: 5,
      subject: 'English & Swahili',
    },
    {
      name: 'Mary Mutua',
      role: 'Single Parent',
      location: 'Kisumu',
      content: 'Anonymous mode gives me confidence to ask questions I might be embarrassed about. The M-Pesa integration makes payments so convenient!',
      rating: 5,
      subject: 'Social Studies',
    },
    {
      name: 'James Kipkoech',
      role: 'Father of 4',
      location: 'Nakuru',
      content: 'The offline mode is a lifesaver! Questions sync when internet returns, and the family profiles help me track each child\'s progress.',
      rating: 5,
      subject: 'Science & Mathematics',
    },
  ];

  return (
    <section id="testimonials" className="py-20 bg-gradient-to-br from-coral/5 to-teal/5 relative overflow-hidden">
      {/* Animated Confetti */}
      {showConfetti && (
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute animate-confetti"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
              }}
            >
              <div className="w-2 h-2 bg-coral rounded-full"></div>
            </div>
          ))}
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold font-poppins text-charcoal mb-6">
            Loved by Kenyan Parents
          </h2>
          <p className="text-xl text-midgrey max-w-3xl mx-auto">
            See what parents across Kenya are saying about their experience with Jibu AI.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 border border-coral-200 hover:shadow-2xl transition-all duration-300 hover:-translate-y-1 transform"
            >
              <div className="flex items-center mb-6">
                <Quote className="h-12 w-12 text-coral mb-4" />
              </div>
              
              <div className="flex mb-6">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="h-6 w-6 text-sunny fill-current" />
                ))}
              </div>

              <p className="text-charcoal mb-8 leading-relaxed text-lg">
                "{testimonial.content}"
              </p>

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-coral to-teal rounded-full flex items-center justify-center text-white font-semibold font-poppins text-xl mr-4">
                    {testimonial.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-semibold font-poppins text-charcoal text-lg">{testimonial.name}</h4>
                    <p className="text-midgrey">{testimonial.role} • {testimonial.location}</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="bg-teal/10 text-teal px-3 py-1 rounded-full text-sm font-medium">
                    {testimonial.subject}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Trust Indicators */}
        <div className="text-center mt-20">
          <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-10 border border-coral-200 max-w-5xl mx-auto shadow-2xl">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="text-5xl font-bold font-poppins text-coral mb-3">4.9/5</div>
                <div className="text-midgrey">App Store Rating</div>
              </div>
              <div className="text-center">
                <div className="text-5xl font-bold font-poppins text-teal mb-3">10K+</div>
                <div className="text-midgrey">Happy Families</div>
              </div>
              <div className="text-center">
                <div className="text-5xl font-bold font-poppins text-sunny-600 mb-3">95%</div>
                <div className="text-midgrey">Success Rate</div>
              </div>
              <div className="text-center">
                <div className="text-5xl font-bold font-poppins text-success mb-3">24/7</div>
                <div className="text-midgrey">Support Available</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
