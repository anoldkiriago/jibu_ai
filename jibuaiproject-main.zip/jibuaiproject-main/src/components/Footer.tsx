
import React from 'react';
import { BookOpen, Mail, Phone, MessageSquare, Globe, Heart } from 'lucide-react';

export const Footer = () => {
  const footerLinks = {
    product: [
      { name: 'How It Works', href: '#how-it-works' },
      { name: 'Features', href: '#features' },
      { name: 'Pricing', href: '#pricing' },
      { name: 'Demo', href: '#demo' },
    ],
    support: [
      { name: 'Help Center', href: '#' },
      { name: 'Contact Us', href: '#contact' },
      { name: 'WhatsApp Support', href: 'https://wa.me/254700123456' },
      { name: 'Parent Community', href: '#' },
    ],
    legal: [
      { name: 'Privacy Policy', href: '#' },
      { name: 'Terms of Service', href: '#' },
      { name: 'Data Protection', href: '#' },
      { name: 'Security', href: '#' },
    ],
    company: [
      { name: 'About Us', href: '#' },
      { name: 'Careers', href: '#' },
      { name: 'Blog', href: '#' },
      { name: 'Press Kit', href: '#' },
    ],
  };

  return (
    <footer className="bg-charcoal text-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-8">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-3 mb-8">
              <div className="bg-gradient-to-r from-coral to-teal p-3 rounded-2xl">
                <BookOpen className="h-8 w-8 text-white" />
              </div>
              <span className="text-2xl font-bold font-poppins">Jibu AI</span>
            </div>
            <p className="text-gray-300 mb-8 max-w-md text-lg leading-relaxed">
              Empowering Kenyan parents to support their children's education with AI-powered homework assistance in English and Swahili.
            </p>
            <div className="flex items-center space-x-2 mb-6">
              <Globe className="h-5 w-5 text-coral" />
              <span className="text-gray-300">English | Swahili</span>
            </div>
            <div className="flex space-x-4">
              <div className="bg-coral/20 p-3 rounded-2xl hover:bg-coral/30 transition-colors cursor-pointer">
                <Mail className="h-6 w-6 text-coral" />
              </div>
              <div className="bg-teal/20 p-3 rounded-2xl hover:bg-teal/30 transition-colors cursor-pointer">
                <Phone className="h-6 w-6 text-teal" />
              </div>
              <div className="bg-success/20 p-3 rounded-2xl hover:bg-success/30 transition-colors cursor-pointer">
                <MessageSquare className="h-6 w-6 text-success" />
              </div>
            </div>
          </div>

          {/* Product Links */}
          <div>
            <h3 className="font-semibold font-poppins text-xl mb-6 text-coral">Product</h3>
            <ul className="space-y-4">
              {footerLinks.product.map((link, index) => (
                <li key={index}>
                  <a
                    href={link.href}
                    className="text-gray-300 hover:text-white transition-colors text-lg"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Support Links */}
          <div>
            <h3 className="font-semibold font-poppins text-xl mb-6 text-teal">Support</h3>
            <ul className="space-y-4">
              {footerLinks.support.map((link, index) => (
                <li key={index}>
                  <a
                    href={link.href}
                    className="text-gray-300 hover:text-white transition-colors text-lg"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Company Links */}
          <div>
            <h3 className="font-semibold font-poppins text-xl mb-6 text-sunny">Company</h3>
            <ul className="space-y-4">
              {footerLinks.company.map((link, index) => (
                <li key={index}>
                  <a
                    href={link.href}
                    className="text-gray-300 hover:text-white transition-colors text-lg"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal Links */}
          <div>
            <h3 className="font-semibold font-poppins text-xl mb-6 text-lavender">Legal</h3>
            <ul className="space-y-4">
              {footerLinks.legal.map((link, index) => (
                <li key={index}>
                  <a
                    href={link.href}
                    className="text-gray-300 hover:text-white transition-colors text-lg"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-700 mt-16 pt-10">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-6 md:space-y-0">
            <div className="text-gray-400 text-lg">
              © 2024 Jibu AI. All rights reserved.
            </div>
            <div className="flex items-center space-x-8 text-lg text-gray-400">
              <div className="flex items-center space-x-2">
                <span>Made in Kenya</span>
                <span className="text-2xl">🇰🇪</span>
              </div>
              <span>•</span>
              <div className="flex items-center space-x-2">
                <span>Powered by AI</span>
                <span className="text-coral">🤖</span>
              </div>
              <span>•</span>
              <div className="flex items-center space-x-2">
                <span>Built with</span>
                <Heart className="h-5 w-5 text-coral fill-current" />
              </div>
            </div>
          </div>
          
          {/* Security & Trust Badges */}
          <div className="flex flex-wrap justify-center items-center space-x-8 mt-8 pt-8 border-t border-gray-800">
            <div className="bg-success/10 text-success px-4 py-2 rounded-full font-medium">
              🔒 Bank-Level Security
            </div>
            <div className="bg-coral/10 text-coral px-4 py-2 rounded-full font-medium">
              🛡️ GDPR Compliant
            </div>
            <div className="bg-teal/10 text-teal px-4 py-2 rounded-full font-medium">
              ⚡ 24/7 Support
            </div>
            <div className="bg-sunny/20 text-sunny px-4 py-2 rounded-full font-medium">
              📱 M-Pesa Enabled
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};
