
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Mail, Phone, MessageSquare, Clock } from 'lucide-react';

export const Contact = () => {
  return (
    <section id="contact" className="py-20 bg-gradient-to-br from-coral/5 to-teal/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold font-poppins text-charcoal mb-6">
            Get in Touch
          </h2>
          <p className="text-xl text-midgrey max-w-3xl mx-auto">
            Have questions or need support? We're here to help you and your family succeed. Available 24/7!
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Contact Form */}
          <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-10 border border-coral-200 shadow-2xl">
            <h3 className="text-3xl font-semibold font-poppins text-charcoal mb-8">Send us a message</h3>
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium font-poppins text-charcoal mb-3">
                    First Name
                  </label>
                  <Input
                    type="text"
                    placeholder="Your first name"
                    className="w-full rounded-2xl border-coral-200 focus:border-coral focus:ring-coral text-lg p-4"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium font-poppins text-charcoal mb-3">
                    Last Name
                  </label>
                  <Input
                    type="text"
                    placeholder="Your last name"
                    className="w-full rounded-2xl border-coral-200 focus:border-coral focus:ring-coral text-lg p-4"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium font-poppins text-charcoal mb-3">
                  Email Address
                </label>
                <Input
                  type="email"
                  placeholder="your.email@example.com"
                  className="w-full rounded-2xl border-coral-200 focus:border-coral focus:ring-coral text-lg p-4"
                />
              </div>

              <div>
                <label className="block text-sm font-medium font-poppins text-charcoal mb-3">
                  Phone Number (Optional)
                </label>
                <Input
                  type="tel"
                  placeholder="+254 xxx xxx xxx"
                  className="w-full rounded-2xl border-coral-200 focus:border-coral focus:ring-coral text-lg p-4"
                />
              </div>

              <div>
                <label className="block text-sm font-medium font-poppins text-charcoal mb-3">
                  Message
                </label>
                <Textarea
                  placeholder="How can Jibu AI help you?"
                  rows={5}
                  className="w-full rounded-2xl border-coral-200 focus:border-coral focus:ring-coral text-lg p-4"
                />
              </div>

              <Button className="w-full bg-gradient-to-r from-coral to-teal hover:from-coral-600 hover:to-teal-600 text-white py-4 rounded-2xl font-semibold font-poppins text-lg shadow-2xl hover:shadow-3xl transition-all duration-300">
                Send Message
              </Button>
            </form>
          </div>

          {/* Contact Information */}
          <div className="space-y-8">
            <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 border border-coral-200 shadow-xl">
              <div className="flex items-center space-x-6 mb-6">
                <div className="bg-coral p-4 rounded-2xl">
                  <Mail className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h4 className="font-semibold font-poppins text-charcoal text-xl">Email Support</h4>
                  <p className="text-midgrey">We respond within 1 hour, 24/7</p>
                </div>
              </div>
              <p className="text-coral font-medium text-lg">support@jibuai.co.ke</p>
            </div>

            <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 border border-teal-200 shadow-xl">
              <div className="flex items-center space-x-6 mb-6">
                <div className="bg-teal p-4 rounded-2xl">
                  <Phone className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h4 className="font-semibold font-poppins text-charcoal text-xl">Phone Support</h4>
                  <p className="text-midgrey">Available 24/7 for all users</p>
                </div>
              </div>
              <p className="text-teal font-medium text-lg">+254 700 123 456</p>
            </div>

            <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 border border-success/30 shadow-xl">
              <div className="flex items-center space-x-6 mb-6">
                <div className="bg-success p-4 rounded-2xl">
                  <MessageSquare className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h4 className="font-semibold font-poppins text-charcoal text-xl">WhatsApp Support</h4>
                  <p className="text-midgrey">Instant responses, 24/7 availability</p>
                </div>
              </div>
              <Button
                onClick={() => window.open('https://wa.me/254700123456', '_blank')}
                className="w-full bg-success hover:bg-green-600 text-white rounded-2xl py-3 font-semibold font-poppins shadow-xl"
              >
                Chat on WhatsApp
              </Button>
            </div>

            {/* Support Hours */}
            <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 border border-sunny-300 shadow-xl">
              <div className="flex items-center space-x-6 mb-6">
                <div className="bg-sunny p-4 rounded-2xl">
                  <Clock className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h4 className="font-semibold font-poppins text-charcoal text-xl">Support Hours</h4>
                  <p className="text-midgrey">We're always here for you</p>
                </div>
              </div>
              <div className="space-y-3 text-lg">
                <div className="flex justify-between items-center">
                  <span className="text-charcoal font-medium">All Days</span>
                  <span className="text-success font-bold">24/7 Available</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-midgrey">WhatsApp</span>
                  <span className="text-success">Instant Response</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-midgrey">Email</span>
                  <span className="text-success">Within 1 Hour</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-midgrey">Phone</span>
                  <span className="text-success">24/7 Hotline</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
