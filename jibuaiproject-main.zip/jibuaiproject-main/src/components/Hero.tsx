
import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowDown, BookOpen, Mic, Camera, Sparkles } from 'lucide-react';

export const Hero = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Hero Background with Professional Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1609220136736-443140cffec6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80')`
        }}
      >
        {/* Subtle professional overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/40 to-black/50"></div>
      </div>

      {/* Animated Floating Icons with Professional Styling */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-16 h-16 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center animate-float transition-all duration-500 hover:scale-110">
          <BookOpen className="h-8 w-8 text-white/80" />
        </div>
        <div className="absolute top-32 right-20 w-14 h-14 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center animate-float-delayed transition-all duration-500 hover:scale-110">
          <Sparkles className="h-7 w-7 text-white/80" />
        </div>
        <div className="absolute bottom-40 left-20 w-18 h-18 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center animate-float-delayed-2 transition-all duration-500 hover:scale-110">
          <Camera className="h-9 w-9 text-white/80" />
        </div>
        <div className="absolute bottom-32 right-16 w-12 h-12 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center animate-float transition-all duration-500 hover:scale-110">
          <Mic className="h-6 w-6 text-white/80" />
        </div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="max-w-4xl mx-auto">
          {/* Professional Badge */}
          <div className="inline-flex items-center space-x-2 bg-white/95 backdrop-blur-sm px-6 py-3 rounded-full border border-white/20 mb-8 shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-105">
            <div className="flex -space-x-1">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="w-2 h-2 bg-coral rounded-full"></div>
              ))}
            </div>
            <span className="text-sm font-medium text-charcoal">Trusted by 10,000+ Parents</span>
          </div>

          {/* Main Heading with Professional Typography */}
          <h1 className="text-4xl md:text-7xl font-bold font-poppins text-white mb-6 leading-tight drop-shadow-lg transition-all duration-700 ease-out">
            <span className="opacity-0 animate-fade-in [animation-delay:200ms] [animation-fill-mode:forwards]">
              Snap a Photo.
            </span>
            <span className="block text-coral drop-shadow-lg opacity-0 animate-fade-in [animation-delay:400ms] [animation-fill-mode:forwards]">
              Get Instant Homework Help.
            </span>
          </h1>

          {/* Professional Subheading */}
          <p className="text-xl md:text-2xl text-white/95 mb-10 max-w-3xl mx-auto leading-relaxed drop-shadow-md opacity-0 animate-fade-in [animation-delay:600ms] [animation-fill-mode:forwards]">
            Jibu AI helps parents explain tricky assignments in simple, child-friendly language — in English or Swahili.
          </p>

          {/* Professional CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6 mb-12 opacity-0 animate-fade-in [animation-delay:800ms] [animation-fill-mode:forwards]">
            <Button size="lg" className="bg-coral hover:bg-coral-600 text-white px-10 py-4 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 hover:-translate-y-1">
              Try Free
            </Button>
            <Button size="lg" className="bg-white/10 backdrop-blur-sm hover:bg-white/20 text-white border border-white/30 px-10 py-4 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 hover:-translate-y-1">
              Watch Demo
            </Button>
          </div>

          {/* Professional Statistics Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 max-w-3xl mx-auto opacity-0 animate-fade-in [animation-delay:1000ms] [animation-fill-mode:forwards]">
            <div className="text-center bg-white/95 backdrop-blur-sm rounded-xl p-6 shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-105 hover:-translate-y-2">
              <div className="text-4xl font-bold font-poppins text-coral mb-2 transition-all duration-300">10K+</div>
              <div className="text-charcoal font-medium">Parents Helped</div>
            </div>
            <div className="text-center bg-white/95 backdrop-blur-sm rounded-xl p-6 shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-105 hover:-translate-y-2">
              <div className="text-4xl font-bold font-poppins text-teal mb-2 transition-all duration-300">50K+</div>
              <div className="text-charcoal font-medium">Questions Answered</div>
            </div>
            <div className="text-center bg-white/95 backdrop-blur-sm rounded-xl p-6 shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-105 hover:-translate-y-2">
              <div className="text-4xl font-bold font-poppins text-sunny-600 mb-2 transition-all duration-300">4.9★</div>
              <div className="text-charcoal font-medium">Average Rating</div>
            </div>
          </div>
        </div>

        {/* Professional Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce opacity-0 animate-fade-in [animation-delay:1200ms] [animation-fill-mode:forwards]">
          <ArrowDown className="h-6 w-6 text-white/80 drop-shadow-lg transition-all duration-300 hover:text-white" />
        </div>
      </div>
    </section>
  );
};
