
import React from 'react';
import { Button } from '@/components/ui/button';
import { Check, Star, Zap } from 'lucide-react';

export const Pricing = () => {
  const plans = [
    {
      name: 'Free Plan',
      price: 'KES 0',
      period: 'forever',
      description: 'Perfect for getting started',
      features: [
        '5 questions per day',
        'Basic explanations',
        'Photo upload',
        'English & Swahili support',
        'Community access',
      ],
      cta: 'Start Free',
      popular: false,
      color: 'border-gray-200',
      payAsYouGo: false,
    },
    {
      name: 'Pay-As-You-Go',
      price: 'KES 10',
      period: 'per question',
      description: 'Flexible option for occasional use',
      features: [
        'Unlimited single questions',
        'Detailed explanations',
        'Voice-to-text support',
        'Read-aloud feature',
        'Anonymous mode',
        'M-Pesa payments',
      ],
      cta: 'Buy Questions',
      popular: false,
      color: 'border-teal-200',
      payAsYouGo: true,
    },
    {
      name: 'Family Plan',
      price: 'KES 400',
      period: 'per month',
      description: 'Best value for families',
      features: [
        'Unlimited questions',
        'All premium features',
        'Multiple child profiles',
        'Learning history & analytics',
        'Emotion-aware responses',
        'Offline mode',
        'Priority support',
        'Parent community access',
      ],
      cta: 'Start Family Plan',
      popular: true,
      color: 'border-coral-200 ring-2 ring-coral',
      payAsYouGo: false,
    },
    {
      name: 'Premium',
      price: 'KES 800',
      period: 'per month',
      description: 'Advanced features + live tutors',
      features: [
        'Everything in Family Plan',
        'Live tutor access 24/7',
        'Homework panic button',
        'Step-by-step solutions',
        'Subject deep dives',
        'WhatsApp priority support',
        'School partnerships',
        'Blockchain explanation logs',
      ],
      cta: 'Go Premium',
      popular: false,
      color: 'border-sunny-300',
      payAsYouGo: false,
    },
  ];

  return (
    <section id="pricing" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold font-poppins text-charcoal mb-6">
            Simple, Transparent Pricing
          </h2>
          <p className="text-xl text-midgrey max-w-3xl mx-auto">
            Choose the plan that works best for your family. All plans include our core AI features with M-Pesa support.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`relative bg-white rounded-3xl border-2 ${plan.color} p-8 hover:shadow-2xl transition-all duration-300 ${
                plan.popular ? 'scale-105 shadow-2xl' : 'hover:scale-105'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-gradient-to-r from-coral to-teal text-white px-6 py-2 rounded-full text-sm font-semibold font-poppins flex items-center space-x-1 shadow-lg">
                    <Star className="h-4 w-4" />
                    <span>Most Popular</span>
                  </div>
                </div>
              )}

              {plan.payAsYouGo && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-teal text-white px-6 py-2 rounded-full text-sm font-semibold font-poppins flex items-center space-x-1 shadow-lg">
                    <Zap className="h-4 w-4" />
                    <span>Flexible</span>
                  </div>
                </div>
              )}

              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold font-poppins text-charcoal mb-3">{plan.name}</h3>
                <p className="text-midgrey mb-6">{plan.description}</p>
                <div className="mb-6">
                  <span className="text-4xl font-bold font-poppins text-charcoal">{plan.price}</span>
                  <span className="text-midgrey ml-2">/{plan.period}</span>
                </div>
              </div>

              <ul className="space-y-4 mb-8">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center space-x-3">
                    <Check className="h-5 w-5 text-success flex-shrink-0" />
                    <span className="text-midgrey">{feature}</span>
                  </li>
                ))}
              </ul>

              <Button
                className={`w-full py-4 font-semibold font-poppins rounded-2xl transition-all duration-300 text-lg ${
                  plan.popular
                    ? 'bg-gradient-to-r from-coral to-teal hover:from-coral-600 hover:to-teal-600 text-white shadow-xl'
                    : plan.payAsYouGo
                    ? 'bg-teal hover:bg-teal-600 text-white shadow-lg'
                    : 'border-2 border-coral text-coral hover:bg-coral hover:text-white shadow-lg'
                }`}
                variant={plan.popular || plan.payAsYouGo ? 'default' : 'outline'}
              >
                {plan.cta}
              </Button>
            </div>
          ))}
        </div>

        {/* Payment Methods */}
        <div className="text-center mt-16">
          <p className="text-midgrey mb-6 text-lg">🔒 Secure payment options available 24/7</p>
          <div className="flex justify-center items-center space-x-8 text-lg">
            <div className="bg-success/10 text-success px-6 py-3 rounded-full font-medium font-poppins flex items-center space-x-2">
              <span>📱</span>
              <span>M-Pesa</span>
            </div>
            <div className="bg-coral/10 text-coral px-6 py-3 rounded-full font-medium font-poppins flex items-center space-x-2">
              <span>💳</span>
              <span>Visa</span>
            </div>
            <div className="bg-teal/10 text-teal px-6 py-3 rounded-full font-medium font-poppins flex items-center space-x-2">
              <span>💳</span>
              <span>Mastercard</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
