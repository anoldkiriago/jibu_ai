
import React from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

export const FAQ = () => {
  const faqs = [
    {
      question: 'How does Jibu AI work with photos and voice?',
      answer: 'Simply take a photo of any homework question or speak it aloud in English or Swahili. Our advanced AI uses computer vision and speech recognition to understand the question and provide clear, age-appropriate explanations.',
    },
    {
      question: 'What subjects does Jibu AI cover?',
      answer: 'We cover all major subjects including Mathematics, Science, English, Swahili, Social Studies, and more. Our AI is specifically trained on the Kenyan curriculum and understands local context.',
    },
    {
      question: 'Is my data safe and secure?',
      answer: 'Absolutely! We use bank-level encryption (AES-256), HTTPS TLS 1.3, and never share your personal information. Our anonymous mode lets you ask questions without storing any identifying data.',
    },
    {
      question: 'How does the emotion-aware AI work?',
      answer: 'Our AI can detect frustration or confusion in voice inputs and text, then responds with gentler, more encouraging explanations. This helps reduce homework stress for both parents and children.',
    },
    {
      question: 'What payment methods do you accept?',
      answer: 'We accept M-Pesa (our most popular option), Visa, and Mastercard. All payments are processed securely with 24/7 support available.',
    },
    {
      question: 'Can I use Jibu AI offline?',
      answer: 'Yes! Our offline mode lets you type or speak questions when you don\'t have internet. Questions are automatically synced and answered when your connection returns.',
    },
    {
      question: 'How does the multilingual support work?',
      answer: 'Jibu AI provides explanations in both English and Swahili, with perfect cultural context. You can also ask questions in either language and get responses in your preferred language.',
    },
    {
      question: 'What is the homework panic button?',
      answer: 'It\'s a premium feature that connects you instantly to live tutors when you need urgent help. Perfect for those last-minute homework emergencies!',
    },
    {
      question: 'How accurate are the explanations?',
      answer: 'Our AI has a 95% accuracy rate and is continuously improved with feedback from Kenyan educators. Premium users can access live tutors for additional verification.',
    },
    {
      question: 'Is there really 24/7 support?',
      answer: 'Yes! Our support team is available 24/7 via WhatsApp, email, and phone. We understand that homework doesn\'t follow business hours.',
    },
  ];

  return (
    <section id="faq" className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold font-poppins text-charcoal mb-6">
            Frequently Asked Questions
          </h2>
          <p className="text-xl text-midgrey">
            Everything you need to know about Jibu AI
          </p>
        </div>

        <Accordion type="single" collapsible className="w-full space-y-4">
          {faqs.map((faq, index) => (
            <AccordionItem
              key={index}
              value={`item-${index}`}
              className="bg-gradient-to-r from-coral/5 to-teal/5 rounded-2xl border border-coral-200 px-8"
            >
              <AccordionTrigger className="text-left font-semibold font-poppins text-charcoal hover:text-coral py-8 text-lg">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-midgrey leading-relaxed pb-8 text-lg">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>

        <div className="text-center mt-16">
          <p className="text-midgrey mb-6 text-lg">Still have questions?</p>
          <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-4">
            <button className="bg-gradient-to-r from-coral to-teal hover:from-coral-600 hover:to-teal-600 text-white px-8 py-4 rounded-2xl font-semibold font-poppins shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-105">
              Contact Support
            </button>
            <button
              onClick={() => window.open('https://wa.me/254700123456', '_blank')}
              className="bg-success hover:bg-green-600 text-white px-8 py-4 rounded-2xl font-semibold font-poppins shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:scale-105"
            >
              WhatsApp Us
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
